cd ~/os161/src/kern/conf
./config ASST3
cd ../compile/ASST3
make depend
make
make install
