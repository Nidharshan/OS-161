/* Automatically generated; do not edit */
#ifndef _OPT_NEWVM_H_
#define _OPT_NEWVM_H_
#define OPT_NEWVM 0
#endif /* _OPT_NEWVM_H_ */
