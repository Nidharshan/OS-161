#ifndef _SYSCALL_H_
#define _SYSCALL_H_

/*
 * Prototypes for IN-KERNEL entry points for system call implementations.
 */

int sys_reboot(int code);
int sys_sbrk(int my_size, int *err);
int sys_read(int filehandle, char *buf, size_t size);
int sys_write(int filehandle, char *buf, size_t size);

#endif /* _SYSCALL_H_ */
